#!/usr/bin/env python3
"""
Binance Futures Testnet Trading Bot — CLI entry point.

Usage examples
--------------
# Market BUY
python cli.py order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001

# Limit SELL
python cli.py order --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 70000

# Stop-Market SELL (bonus order type)
python cli.py order --symbol BTCUSDT --side SELL --type STOP_MARKET --quantity 0.001 --stop-price 60000

# Account info
python cli.py account

# Open orders
python cli.py open-orders --symbol BTCUSDT

# Dry-run (validate only, don't submit)
python cli.py order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001 --dry-run
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# Allow running from project root without installing
sys.path.insert(0, str(Path(__file__).parent))

from bot.client import BinanceFuturesClient, BinanceAPIError, NetworkError
from bot.logging_config import setup_logging
from bot.orders import place_order, print_error


# ── Env helpers ────────────────────────────────────────────────────────────────

def _require_env(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        print_error(
            f"Environment variable '{name}' is not set.\n"
            "  Export your testnet credentials before running:\n"
            "    export BINANCE_API_KEY='your-key'\n"
            "    export BINANCE_API_SECRET='your-secret'"
        )
        sys.exit(1)
    return value


def _build_client() -> BinanceFuturesClient:
    api_key = _require_env("BINANCE_API_KEY")
    api_secret = _require_env("BINANCE_API_SECRET")
    return BinanceFuturesClient(api_key=api_key, api_secret=api_secret)


# ── Sub-command handlers ───────────────────────────────────────────────────────

def cmd_order(args: argparse.Namespace) -> None:
    client = _build_client()
    place_order(
        client=client,
        symbol=args.symbol,
        side=args.side,
        order_type=args.type,
        quantity=args.quantity,
        price=args.price,
        stop_price=args.stop_price,
        dry_run=args.dry_run,
    )


def cmd_account(args: argparse.Namespace) -> None:
    client = _build_client()
    logger = __import__("logging").getLogger("trading_bot.cli")
    try:
        info = client.get_account()
        print("\n── Account Info ────────────────────────────────")
        print(f"  Total Wallet Balance : {info.get('totalWalletBalance', '—')} USDT")
        print(f"  Unrealised PnL       : {info.get('totalUnrealizedProfit', '—')} USDT")
        print(f"  Available Balance    : {info.get('availableBalance', '—')} USDT")
        print(f"  Can Trade            : {info.get('canTrade', '—')}")
        print()
        logger.info("Fetched account info successfully.")
    except (BinanceAPIError, NetworkError) as exc:
        logger.error("Failed to fetch account info: %s", exc)
        print_error(str(exc))
        sys.exit(1)


def cmd_open_orders(args: argparse.Namespace) -> None:
    client = _build_client()
    logger = __import__("logging").getLogger("trading_bot.cli")
    try:
        orders = client.get_open_orders(symbol=args.symbol)
        if not orders:
            print(f"\n  No open orders{' for ' + args.symbol if args.symbol else ''}.\n")
        else:
            print(f"\n── Open Orders ({len(orders)}) ───────────────────────────")
            for o in orders:
                print(
                    f"  [{o.get('orderId')}] {o.get('symbol')} "
                    f"{o.get('side')} {o.get('type')} "
                    f"qty={o.get('origQty')} price={o.get('price')} "
                    f"status={o.get('status')}"
                )
            print()
        logger.info("Fetched %d open orders.", len(orders))
    except (BinanceAPIError, NetworkError) as exc:
        logger.error("Failed to fetch open orders: %s", exc)
        print_error(str(exc))
        sys.exit(1)


def cmd_positions(args: argparse.Namespace) -> None:
    client = _build_client()
    logger = __import__("logging").getLogger("trading_bot.cli")
    try:
        positions = client.get_position_risk(symbol=args.symbol)
        active = [p for p in positions if float(p.get("positionAmt", 0)) != 0]
        if not active:
            print(f"\n  No active positions{' for ' + args.symbol if args.symbol else ''}.\n")
        else:
            print(f"\n── Active Positions ({len(active)}) ─────────────────────")
            for p in active:
                print(
                    f"  {p.get('symbol')} | amt={p.get('positionAmt')} "
                    f"entry={p.get('entryPrice')} "
                    f"pnl={p.get('unRealizedProfit')} USDT"
                )
            print()
        logger.info("Fetched position risk data.")
    except (BinanceAPIError, NetworkError) as exc:
        logger.error("Failed to fetch positions: %s", exc)
        print_error(str(exc))
        sys.exit(1)


# ── Argument parser ────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        description="Binance Futures Testnet Trading Bot",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Environment variables (required):
  BINANCE_API_KEY      Your testnet API key
  BINANCE_API_SECRET   Your testnet API secret

Examples:
  python cli.py order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
  python cli.py order --symbol ETHUSDT --side SELL --type LIMIT --quantity 0.01 --price 3200
  python cli.py order --symbol BTCUSDT --side SELL --type STOP_MARKET --quantity 0.001 --stop-price 60000
  python cli.py account
  python cli.py open-orders --symbol BTCUSDT
  python cli.py positions
        """,
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Console log verbosity (default: INFO)",
    )

    sub = parser.add_subparsers(dest="command", metavar="COMMAND")
    sub.required = True

    # ── order ──────────────────────────────────────────────────────────────
    p_order = sub.add_parser("order", help="Place a new futures order")
    p_order.add_argument(
        "--symbol", "-s",
        required=True,
        metavar="SYMBOL",
        help="Trading pair, e.g. BTCUSDT",
    )
    p_order.add_argument(
        "--side",
        required=True,
        choices=["BUY", "SELL"],
        help="Order side",
    )
    p_order.add_argument(
        "--type", "-t",
        required=True,
        dest="type",
        choices=["MARKET", "LIMIT", "STOP_MARKET"],
        help="Order type",
    )
    p_order.add_argument(
        "--quantity", "-q",
        required=True,
        help="Order quantity (base asset)",
    )
    p_order.add_argument(
        "--price", "-p",
        default=None,
        help="Limit price (required for LIMIT orders)",
    )
    p_order.add_argument(
        "--stop-price",
        default=None,
        dest="stop_price",
        help="Stop price (required for STOP_MARKET orders)",
    )
    p_order.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate and preview without submitting",
    )
    p_order.set_defaults(func=cmd_order)

    # ── account ────────────────────────────────────────────────────────────
    p_acc = sub.add_parser("account", help="Show futures account balance")
    p_acc.set_defaults(func=cmd_account)

    # ── open-orders ────────────────────────────────────────────────────────
    p_oo = sub.add_parser("open-orders", help="List open orders")
    p_oo.add_argument("--symbol", "-s", default=None, help="Filter by symbol")
    p_oo.set_defaults(func=cmd_open_orders)

    # ── positions ──────────────────────────────────────────────────────────
    p_pos = sub.add_parser("positions", help="Show active positions")
    p_pos.add_argument("--symbol", "-s", default=None, help="Filter by symbol")
    p_pos.set_defaults(func=cmd_positions)

    return parser


# ── Entry point ────────────────────────────────────────────────────────────────

def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    logger = setup_logging(level=args.log_level)
    logger.debug("CLI args: %s", vars(args))

    args.func(args)


if __name__ == "__main__":
    main()
