"""
Binance Futures Testnet REST client.

Wraps raw HTTP calls to the USDT-M Futures testnet API,
handling HMAC-SHA256 signing, timestamping, and error parsing.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import time
from typing import Any, Optional
from urllib.parse import urlencode

import requests

logger = logging.getLogger("trading_bot.client")

TESTNET_BASE_URL = "https://testnet.binancefuture.com"
RECV_WINDOW = 5_000  # ms


class BinanceAPIError(Exception):
    """Raised when Binance returns a non-2xx response or error JSON."""

    def __init__(self, code: int, message: str, http_status: int = 0):
        self.code = code
        self.message = message
        self.http_status = http_status
        super().__init__(f"Binance API error {code}: {message} (HTTP {http_status})")


class NetworkError(Exception):
    """Raised on network-level failures (timeout, connection refused, etc.)."""


class BinanceFuturesClient:
    """
    Thin wrapper around the Binance USDT-M Futures Testnet REST API.

    Responsibilities
    ----------------
    - Sign requests with HMAC-SHA256
    - Attach API key header
    - Log every request/response at DEBUG level
    - Raise typed exceptions on errors
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        base_url: str = TESTNET_BASE_URL,
        timeout: int = 10,
    ):
        if not api_key or not api_secret:
            raise ValueError("api_key and api_secret must not be empty.")
        self._api_key = api_key
        self._api_secret = api_secret.encode()
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(
            {
                "X-MBX-APIKEY": self._api_key,
                "Content-Type": "application/x-www-form-urlencoded",
            }
        )
        logger.debug("BinanceFuturesClient initialised (base_url=%s)", self._base_url)

    # ── Internals ──────────────────────────────────────────────────────────

    def _sign(self, params: dict) -> dict:
        params["timestamp"] = int(time.time() * 1000)
        params["recvWindow"] = RECV_WINDOW
        query = urlencode(params)
        signature = hmac.new(
            self._api_secret, query.encode(), hashlib.sha256
        ).hexdigest()
        params["signature"] = signature
        return params

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[dict] = None,
        signed: bool = True,
    ) -> Any:
        url = f"{self._base_url}{path}"
        params = dict(params or {})
        if signed:
            params = self._sign(params)

        logger.debug(
            "→ %s %s  params=%s",
            method.upper(),
            path,
            {k: v for k, v in params.items() if k != "signature"},
        )

        try:
            if method.upper() in ("GET", "DELETE"):
                resp = self._session.request(
                    method, url, params=params, timeout=self._timeout
                )
            else:
                resp = self._session.request(
                    method, url, data=params, timeout=self._timeout
                )
        except requests.exceptions.Timeout as exc:
            logger.error("Request timed out: %s", exc)
            raise NetworkError(f"Request timed out after {self._timeout}s") from exc
        except requests.exceptions.ConnectionError as exc:
            logger.error("Connection error: %s", exc)
            raise NetworkError(f"Connection error: {exc}") from exc

        logger.debug(
            "← HTTP %s  body=%s",
            resp.status_code,
            resp.text[:500],
        )

        # Parse JSON (Binance always returns JSON)
        try:
            data = resp.json()
        except ValueError:
            raise BinanceAPIError(
                -1, f"Non-JSON response: {resp.text[:200]}", resp.status_code
            )

        # Binance error responses are 4xx/5xx with {"code": ..., "msg": ...}
        if not resp.ok:
            code = data.get("code", resp.status_code)
            msg = data.get("msg", resp.text)
            logger.error("API error %s: %s (HTTP %s)", code, msg, resp.status_code)
            raise BinanceAPIError(code, msg, resp.status_code)

        return data

    # ── Public API methods ─────────────────────────────────────────────────

    def get_account(self) -> dict:
        """Fetch futures account information."""
        return self._request("GET", "/fapi/v2/account")

    def get_exchange_info(self) -> dict:
        """Fetch exchange info (symbols, filters, etc.)."""
        return self._request("GET", "/fapi/v1/exchangeInfo", signed=False)

    def place_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: str,
        price: Optional[str] = None,
        stop_price: Optional[str] = None,
        time_in_force: str = "GTC",
        reduce_only: bool = False,
    ) -> dict:
        """
        Place a futures order.

        Parameters
        ----------
        symbol       : e.g. "BTCUSDT"
        side         : "BUY" | "SELL"
        order_type   : "MARKET" | "LIMIT" | "STOP_MARKET"
        quantity     : order quantity as string
        price        : required for LIMIT
        stop_price   : required for STOP_MARKET
        time_in_force: "GTC" | "IOC" | "FOK"  (ignored for MARKET)
        reduce_only  : whether the order should only reduce position
        """
        params: dict[str, Any] = {
            "symbol": symbol,
            "side": side,
            "type": order_type,
            "quantity": quantity,
        }
        if order_type == "LIMIT":
            params["price"] = price
            params["timeInForce"] = time_in_force
        if order_type == "STOP_MARKET":
            params["stopPrice"] = stop_price
        if reduce_only:
            params["reduceOnly"] = "true"

        logger.info(
            "Placing %s %s order | symbol=%s qty=%s price=%s stopPrice=%s",
            side,
            order_type,
            symbol,
            quantity,
            price,
            stop_price,
        )
        response = self._request("POST", "/fapi/v1/order", params=params)
        logger.info("Order placed successfully | orderId=%s", response.get("orderId"))
        return response

    def cancel_order(self, symbol: str, order_id: int) -> dict:
        """Cancel an open order by order ID."""
        params = {"symbol": symbol, "orderId": order_id}
        logger.info("Cancelling order %s on %s", order_id, symbol)
        return self._request("DELETE", "/fapi/v1/order", params=params)

    def get_open_orders(self, symbol: Optional[str] = None) -> list:
        """Get all open orders, optionally filtered by symbol."""
        params = {}
        if symbol:
            params["symbol"] = symbol
        return self._request("GET", "/fapi/v1/openOrders", params=params)

    def get_position_risk(self, symbol: Optional[str] = None) -> list:
        """Get current position information."""
        params = {}
        if symbol:
            params["symbol"] = symbol
        return self._request("GET", "/fapi/v2/positionRisk", params=params)
