"""
Order placement logic.

Sits between the CLI and the raw API client.
Handles:
  - calling validators
  - calling client
  - formatting human-readable output
  - structured logging of outcomes
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Optional

from .client import BinanceFuturesClient, BinanceAPIError, NetworkError
from .validators import validate_order_params, ValidationError

logger = logging.getLogger("trading_bot.orders")


# ── Formatting helpers ─────────────────────────────────────────────────────────

def _fmt(value: Optional[str | float | Decimal], default: str = "—") -> str:
    if value is None or value == "" or value == "0" or value == "0.00000000":
        return default
    return str(value)


def print_order_summary(params: dict) -> None:
    """Print a formatted summary of what we're about to send."""
    lines = [
        "",
        "┌─────────────────────────────────────────┐",
        "│          ORDER REQUEST SUMMARY           │",
        "├─────────────────────────────────────────┤",
        f"│  Symbol     : {params['symbol']:<26}│",
        f"│  Side       : {params['side']:<26}│",
        f"│  Type       : {params['order_type']:<26}│",
        f"│  Quantity   : {str(params['quantity']):<26}│",
    ]
    if params.get("price"):
        lines.append(f"│  Price      : {str(params['price']):<26}│")
    if params.get("stop_price"):
        lines.append(f"│  Stop Price : {str(params['stop_price']):<26}│")
    lines += [
        "└─────────────────────────────────────────┘",
        "",
    ]
    print("\n".join(lines))


def print_order_response(response: dict, success: bool = True) -> None:
    """Print a formatted summary of the API response."""
    if not success:
        return

    status = response.get("status", "UNKNOWN")
    order_id = response.get("orderId", "—")
    client_order_id = response.get("clientOrderId", "—")
    symbol = response.get("symbol", "—")
    side = response.get("side", "—")
    order_type = response.get("type", "—")
    orig_qty = _fmt(response.get("origQty"))
    executed_qty = _fmt(response.get("executedQty"))
    avg_price = _fmt(response.get("avgPrice"))
    price = _fmt(response.get("price"))

    lines = [
        "",
        "┌─────────────────────────────────────────┐",
        "│          ORDER RESPONSE DETAILS          │",
        "├─────────────────────────────────────────┤",
        f"│  Order ID   : {str(order_id):<26}│",
        f"│  Client ID  : {str(client_order_id):<26}│",
        f"│  Symbol     : {symbol:<26}│",
        f"│  Side       : {side:<26}│",
        f"│  Type       : {order_type:<26}│",
        f"│  Status     : {status:<26}│",
        f"│  Orig Qty   : {orig_qty:<26}│",
        f"│  Exec Qty   : {executed_qty:<26}│",
        f"│  Avg Price  : {avg_price:<26}│",
        f"│  Price      : {price:<26}│",
        "└─────────────────────────────────────────┘",
        "",
        f"  ✅  Order placed successfully  (orderId={order_id})",
        "",
    ]
    print("\n".join(lines))


def print_error(message: str) -> None:
    print(f"\n  ❌  {message}\n")


# ── Core order function ────────────────────────────────────────────────────────

def place_order(
    client: BinanceFuturesClient,
    symbol: str,
    side: str,
    order_type: str,
    quantity: str | float,
    price: Optional[str | float] = None,
    stop_price: Optional[str | float] = None,
    dry_run: bool = False,
) -> Optional[dict]:
    """
    Validate inputs, print a summary, and place the order.

    Returns the API response dict on success, None on failure.
    """

    # ── Validate ──────────────────────────────────────────────────────────
    try:
        params = validate_order_params(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            price=price,
            stop_price=stop_price,
        )
    except ValidationError as exc:
        logger.warning("Validation failed: %s", exc)
        print_error(str(exc))
        return None

    print_order_summary(params)

    if dry_run:
        print("  ℹ️   Dry-run mode — order NOT sent to exchange.\n")
        logger.info("Dry-run: order not submitted. params=%s", params)
        return None

    # ── Place order ───────────────────────────────────────────────────────
    try:
        response = client.place_order(
            symbol=params["symbol"],
            side=params["side"],
            order_type=params["order_type"],
            quantity=str(params["quantity"]),
            price=str(params["price"]) if params["price"] else None,
            stop_price=str(params["stop_price"]) if params["stop_price"] else None,
        )
    except ValidationError as exc:
        logger.warning("Validation error: %s", exc)
        print_error(str(exc))
        return None
    except BinanceAPIError as exc:
        logger.error(
            "API error placing order | code=%s msg=%s http=%s",
            exc.code,
            exc.message,
            exc.http_status,
        )
        print_error(f"Binance API error {exc.code}: {exc.message}")
        return None
    except NetworkError as exc:
        logger.error("Network error placing order: %s", exc)
        print_error(f"Network error: {exc}")
        return None
    except Exception as exc:
        logger.exception("Unexpected error placing order: %s", exc)
        print_error(f"Unexpected error: {exc}")
        return None

    logger.info(
        "Order result | orderId=%s status=%s executedQty=%s avgPrice=%s",
        response.get("orderId"),
        response.get("status"),
        response.get("executedQty"),
        response.get("avgPrice"),
    )

    print_order_response(response)
    return response
