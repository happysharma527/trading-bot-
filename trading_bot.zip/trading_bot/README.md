# Binance Futures Testnet Trading Bot

A clean, production-structured Python CLI application for placing orders on the **Binance USDT-M Futures Testnet**.

---

## Features

- ✅ **Market** and **Limit** orders (BUY & SELL)
- ✅ **Stop-Market** orders (bonus third order type)
- ✅ Clean CLI with `argparse` — symbol, side, type, quantity, price, stop-price
- ✅ Input validation with descriptive error messages
- ✅ Structured logging → `logs/trading_bot.log` (rotating, DEBUG-level detail)
- ✅ Layered architecture: `client.py` → `orders.py` → `cli.py`
- ✅ Full exception handling: validation errors, API errors, network failures
- ✅ `--dry-run` flag to validate without submitting
- ✅ Account info, open-orders, and positions sub-commands

---

## Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py
│   ├── client.py          # Binance REST client (signing, requests, error parsing)
│   ├── orders.py          # Order placement logic + output formatting
│   ├── validators.py      # Input validation (raises ValidationError)
│   └── logging_config.py  # Rotating file + console logging setup
├── cli.py                 # CLI entry point (argparse sub-commands)
├── logs/
│   └── trading_bot.log    # Auto-created on first run
├── requirements.txt
└── README.md
```

---

## Setup

### 1. Testnet credentials

1. Go to [https://testnet.binancefuture.com](https://testnet.binancefuture.com)
2. Log in with your GitHub account
3. Navigate to **API Management** → generate an API key and secret
4. Export them as environment variables:

```bash
export BINANCE_API_KEY="your_testnet_api_key"
export BINANCE_API_SECRET="your_testnet_api_secret"
```

> **Windows (PowerShell):**
> ```powershell
> $env:BINANCE_API_KEY="your_testnet_api_key"
> $env:BINANCE_API_SECRET="your_testnet_api_secret"
> ```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

Python 3.9+ recommended. No other third-party dependencies — only `requests`.

---

## Running the Bot

All commands are run from the project root directory.

### Place a Market Order

```bash
# BUY 0.001 BTC at market price
python cli.py order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001

# SELL 0.01 ETH at market price
python cli.py order --symbol ETHUSDT --side SELL --type MARKET --quantity 0.01
```

### Place a Limit Order

```bash
# BUY 0.001 BTC at $62,000
python cli.py order --symbol BTCUSDT --side BUY --type LIMIT --quantity 0.001 --price 62000

# SELL 0.001 BTC at $65,000
python cli.py order --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 65000
```

### Place a Stop-Market Order (bonus)

```bash
# Protective SELL stop at $60,000 (triggers market sell if price drops below)
python cli.py order --symbol BTCUSDT --side SELL --type STOP_MARKET --quantity 0.001 --stop-price 60000
```

### Dry-Run (validate only, don't submit)

```bash
python cli.py order --symbol BTCUSDT --side BUY --type LIMIT --quantity 0.001 --price 62000 --dry-run
```

### Other Commands

```bash
# Show account balances
python cli.py account

# List all open orders
python cli.py open-orders

# List open orders for a specific symbol
python cli.py open-orders --symbol BTCUSDT

# Show active positions
python cli.py positions
```

### Log verbosity

```bash
# Show DEBUG-level output on console (API request/response detail)
python cli.py --log-level DEBUG order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
```

---

## Example Output

**Market BUY:**
```
┌─────────────────────────────────────────┐
│          ORDER REQUEST SUMMARY           │
├─────────────────────────────────────────┤
│  Symbol     : BTCUSDT                   │
│  Side       : BUY                       │
│  Type       : MARKET                    │
│  Quantity   : 0.001                     │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│          ORDER RESPONSE DETAILS          │
├─────────────────────────────────────────┤
│  Order ID   : 3865432                   │
│  Symbol     : BTCUSDT                   │
│  Side       : BUY                       │
│  Type       : MARKET                    │
│  Status     : FILLED                    │
│  Orig Qty   : 0.001                     │
│  Exec Qty   : 0.001                     │
│  Avg Price  : 62345.10                  │
└─────────────────────────────────────────┘

  ✅  Order placed successfully  (orderId=3865432)
```

---

## Logging

All API interactions are logged to `logs/trading_bot.log` with:

- **Timestamp** (ISO 8601)
- **Level** (DEBUG / INFO / WARNING / ERROR)
- **Logger name** (module-level)
- **Message** (request params, response body, error details)

The log file rotates at 5 MB and keeps 3 backups. Console output is INFO-level by default.

---

## Assumptions

- Only **USDT-M Futures Testnet** is supported (`https://testnet.binancefuture.com`).
- Quantity precision must match what the testnet exchange filters allow (e.g., 0.001 BTC minimum for BTCUSDT). If you hit a filter error, adjust quantity accordingly.
- Credentials are passed via environment variables only — never hardcoded.
- `timeInForce` defaults to `GTC` (Good Till Cancelled) for LIMIT orders.
- No hedging mode: the bot uses the default `BOTH` position side (one-way mode).

---

## Error Handling

| Scenario | Behaviour |
|---|---|
| Missing required arg (e.g., price for LIMIT) | Clear validation error, no API call |
| Invalid symbol characters | Validation error with example |
| Binance API error (e.g., insufficient margin) | Prints error code + message |
| Network timeout | Descriptive network error message |
| Invalid credentials | API error -2014 or -1102 from exchange |
